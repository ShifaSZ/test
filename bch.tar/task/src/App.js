import React, { useState } from "react"


const stepHeading=["Dimensions & Quantity", "Cardboard Grade",
  "Print Quality", "Optional Extras"]
const colorText=[
 "3 color printing", "2 color printing",
 "Black only printing", "No printing",
 "FantasticBoxCo branding"]
const stepText=[{title:"Dimension & Quantity",
     content:"Enter the width, height, length and quantity of the box(es) you require"},
   {title:"Cardboard Grade",
     content:"FantasticBoxCo offer a variety of grades of cardboard, each altering the price per M^2:"},
   {title:"Print Quality", content:"A variety of printing options are available for any branding / logos which are required:"},
   {title:"Optional Extras", content:"Handle and Reinforced bottom"},
   {title:"Total Cost",content:""},
      ]

const unitPriceTab={"A":0.2, "B":0.1, "C":0.05}
const colorPriceTab=[0.2, 0.1, 0.05, 0]

export default function App() {
  const [activeStep, setActiveStep] = useState(1);
  const [totalPrice, settotalPrice] = useState(0);
  const [width, setwidth] = useState(0);
  const [height, setheight] = useState(0);
  const [length, setlength] = useState(0);
  const [quantity, setquantity] = useState(0);
  const [grade, setgrade] = useState("A");
  const [color, setcolor] = useState(0);
  const [handleFee, sethandleFee] = useState(false);
  const [reinforcedBottom, setreinforcedBottom] = useState(false);
  const [stepValue, setStepValue] = useState(['-','-','-','-']);

  const listItem = [1,2,3,4].map((step)=>(
    <li key={step.toString()}>
        <a href={"#step-"+step}
           className={(step === activeStep)?
             "step step-"+step+" is-active":"step step-"+step}>
            <div className="step-number">{step}</div>
            <h3 className="step-heading">{stepHeading[step-1]}</h3>
            {(step === 1) && 
                                <dl>
                                    <dt>Width:</dt>
                                    <dd>{width}m</dd>
                                    <dt>Height:</dt>
                                    <dd>{height}m</dd>
                                    <dt>Length:</dt>
                                    <dd>{length}m</dd>
                                    <dt>Quantity:</dt>
                                    <dd>{quantity}</dd>
                                </dl>}
            {(step !== 1) && 
            <span className="step-value">{stepValue[step-1]}</span>}
        </a>
    </li>
  ))

  const step1content = ()=>(
    <div>
        <div className="form-row">
            <label htmlFor="width">Width:</label>
            <input type="number" name="width" id="width" value={width}
              min="0" step="0.01"
              onChange={(event)=>{setwidth(event.target.value)}}
            />
        </div>

        <div className="form-row">
            <label htmlFor="height">Height:</label>
            <input type="number" name="height" id="height" value={height}
              min="0" step="0.01"
              onChange={(event)=>{setheight(event.target.value)}}
            />
        </div>

        <div className="form-row">
            <label htmlFor="length">Length:</label>
            <input type="number" name="length" id="length" value={length}
              min="0" step="0.01"
              onChange={(event)=>{setlength(event.target.value)}}
            />
        </div>

        <div className="form-row">
            <label htmlFor="quantity">Quantity:</label>
            <input type="number" name="quantity" id="quantity" value={quantity}
              min="0" step="1"
              onChange={(event)=>{setquantity(event.target.value)}}
            />
        </div>
     </div>
  )

  const gradeList = ["A","B","C"].map((gr)=>(
            <li key={gr}>
                <label>
                    <input type="radio" name="cardboard-grade" value={gr}
                      defaultChecked={gr === grade} disabled = {
                       ((gr === "C") &&
                        ((width*height+width*length+height*length)*2 > 2) )}
                    />
                    <span className="btn btn-radio">
                        {gr} Grade<br/>${unitPriceTab[gr]} m<sup>2</sup>
                    {((gr === "C") &&
                        ((width*height+width*length+height*length)*2 > 2) ) &&
                      <span style={{fontSize:"9px"}}><br/>Not available for boxes larger than 2m<sup>2</sup>
                      </span>}
                    </span>
                </label>
            </li>
  ))
  const step2content = ()=>(
        <ol className="btn-radios-list"
          onChange={(event)=>{
            const newGrade = event.target.value
            //stepValue[1] = newGrade + " Grade"
            //setStepValue(setValue)
            if ((newGrade === "C") && 
                ((width*height+width*length+height*length)*2 > 2) ){
                alert("C Grade is not available for boxes larger than 2^m")
               setgrade(grade)
            }
            else
               setgrade(newGrade)
          }}
         >
          {gradeList}
        </ol>
  )

  const colorList=[0,1,2,3,4].map((cl)=>(
            <li key={cl.toString()}>
                <label>
                    <input type="radio" name="print-quality" value={cl}
                      defaultChecked = {cl === color}/>
                    {cl !== 4 &&
                    <span className="btn btn-radio">
                        {colorText[cl]}<br/>$colorPriceTab[cl] m<sup>2</sup>
                    </span>}
                    {cl === 4 &&
                    <span className="btn btn-radio">
                        <strong>FantasticBoxCo</strong> branding<br/>5% discount on total price
                    </span>}
                </label>
            </li>
  ))

  const step3content = ()=>(
        <ol className="btn-radios-list"
           onChange={(event)=>{
             setcolor(event.target.value)
           }}>
          {colorList}
        </ol>
  )

  const step4content = ()=>(
        <ol className="btn-radios-list"
        >
            <li>
                <label>
                    <input type="checkbox" name="optional-extras"
                      value={handleFee}
                      onClick={(event)=>{
                        sethandleFee(!handleFee)}}
                    />
                    <span className="btn btn-radio">
                        Handles<br/>$0.10 per box
                    </span>
                </label>
            </li>
            <li>
                <label>
                    <input type="checkbox" name="optional-extras"
                      value={reinforcedBottom}
                      onClick={(event)=>{
                        setreinforcedBottom(!reinforcedBottom)}}
                    />
                    <span className="btn btn-radio">
                        Reinforced bottom<br/>$0.05 per box<br/>
                        <small>(only available with grade A cardboard)</small>
                    </span>
                </label>
            </li>
        </ol>
  )

  const setStepText = (step)=>{
    console.log("step text:"+step)
    if (step === 2){
      stepValue[1]=grade + " Grade"
    } else if (step === 3) {
      stepValue[2]=colorText[color]
    } else if (step === 4){
      if (handleFee && reinforcedBottom)
        stepValue[3] = "Handles and Reinforced bottom"
      else if (handleFee)
        stepValue[3] = "Handles"
      else if (reinforcedBottom)
        stepValue[3] = "Reinforced bottom"
      else
        stepValue[3] = "-"
    }
    setStepValue(stepValue)
  }

  function calcPrice(){
    var totalPrice=0
    if (color === 4){
      totalPrice = 2*(width*height+width*length+length*height)*quantity
        *(unitPriceTab[grade])
        +handleFee*0.1*quantity
        +reinforcedBottom*0.05*quantity
      totalPrice = totalPrice*0.95
    } else {
      totalPrice = 2*(width*height+width*length+length*height)*quantity
        *(unitPriceTab[grade]+colorPriceTab[color])
        +handleFee*0.1*quantity
        +reinforcedBottom*0.05*quantity
    }
    return totalPrice.toFixed(2)
  }

  const stepPages = [1,2,3,4].map((step)=>{
    if (step === activeStep){
      return (
      <div id={"step-"+step} className="content-step" key={step.toString()}>
        <h2>Step {step} - {stepText[step-1].title}</h2>
        <p className="intro"> {stepText[step-1].content} </p>
        {(step === 1) && step1content()}
        {(step === 2) && step2content()}
        {(step === 3) && step3content()}
        {(step === 4) && step4content()}
        <div className="form-actions">
          {(step !== 1) &&
            <button type="button" className="btn btn-back"
              onClick={()=>{setActiveStep(activeStep-1)}}
            >
                back
            </button>}
            <button type="button" className="btn btn-primary btn-next" 
              disabled={(step === 1) && (width*height*length*quantity === 0)}
              onClick={()=>{
                setStepText(activeStep)
                if (activeStep === 4){
                  settotalPrice(calcPrice)
                }
                setActiveStep(activeStep+1)}}
            >
                {(step === 4)?"Finish":"Next"}
            </button>
        </div>
      </div>
      )
    }
  })
    return(
      <div className="container">
                <aside>
                    <ul className="progress">
                        {listItem}
                        <li>
                            <a href="#total-cost" className="step step-total-cost">
                                <h3 className="step-total-cost-heading">Total Cost</h3>
                                <div className="step-total-cost-value">${totalPrice}</div>
                            </a>
                        </li>
                    </ul>
                </aside>
                <section>
                    {stepPages}
                    {activeStep === 5 &&
                    <div id="total-cost" className="content-step">
                        <h2>Total Cost</h2>
                        <dl className="breakdown">
                            <dt>Dimensions & Quantity:</dt>
                            <dd>{quantity} x {width}(W)x{height}(H)x{length}(L)</dd>
                            <dt>Cardboard Grade:</dt>
                            <dd>{grade} grade</dd>
                            <dt>Print Quality:</dt>
                            <dd>{colorText[color]}</dd>
                            <dt>Optional Extras:</dt>
                            <dd>
                                <ol>
                                    {handleFee &&
                                    <li>Handles</li>}
                                    {reinforcedBottom &&
                                    <li>Reinforce bottoms</li> }
                                </ol>
                            </dd>
                            <dt>Total Cost:</dt>
                            <dd>${totalPrice}</dd>
                        </dl>
                    </div>}
                </section>
      </div>
    )
}
