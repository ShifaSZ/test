import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
//import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
//import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';

const useStyles = makeStyles({
  root: {
    flexGrow: 1,
  },
  card: {
    minWidth: 240,
    minHeight: 120,
  },
  bullet: {
    display: 'inline-block',
    margin: '0 2px',
    transform: 'scale(0.8)',
  },
  title: {
    fontSize: 14,
  },
  pos: {
    marginBottom: 12,
  },
});

export function ShowCards(props) {
  const classes = useStyles();
  const bull = <span className={classes.bullet}>•</span>;

  return (
    <div className={classes.root}>
      <Grid container spacing={3}>
      {props.steps.map((step, index)=>(
        <Grid item xs={3} key={index}>
      <Card className={classes.card}>
        <CardContent>
          { step.map((item,indexA)=>(
            (index < props.activeStep)&&
            <Typography variant="body2" component="p" key={indexA}>
              {bull}{item}
            </Typography>
          ))}
        </CardContent>
      </Card>
        </Grid>
      ))}
      </Grid>
    </div>
  );
}
