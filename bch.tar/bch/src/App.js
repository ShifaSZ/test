import React from 'react';
//import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import {HorizontalStepper} from './Stepper.js';
import {ShowCards} from './infoCards.js';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
//import FormHelperText from '@material-ui/core/FormHelperText';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import FormLabel from '@material-ui/core/FormLabel';
import Input from '@material-ui/core/Input';
import FormGroup from '@material-ui/core/FormGroup';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';
import Checkbox from '@material-ui/core/Checkbox';
import Grid from '@material-ui/core/Grid';
import Divider from '@material-ui/core/Divider';

var steps=[{title:"Box dimension and quantity", 
     content:"Enter width, height and length of the box you require and enter the quantity of boxes you would like to order"},
   {title:"Select Cardboard grade",
     content:"FantasticBoxCo offer a variety of grades of cardboard, each altering the price per M^2"},
   {title:"Select Print Quality", content:"A variety of printing options are available for any branding / logos which are required"},
   {title:"Optional extras", content:"Handle fees and Reinforced bottom"},
   {title:"Quote",content:"Your choices are:"},
      ]

const unitPriceTab={"A":0.2, "B":0.1, "C":0.05}
const colorPriceTab=[0.2, 0.1, 0.05, 0, -0.05]

const colorText=[
 "3 color printing", "2 color printing",
 "Black only printing", "No printing (plain cardboard)",
 "FantasticBoxCo branding"]


export class App extends React.Component{
  constructor(props){
    super(props)
    this.state = {
      totalPrice:0,
      activeStep:0,
      width:0,
      height:0,
      length:0,
      quantity:0,
      grade:"A",
      color:0,
      handle_fee:false,
      reinforced_bottom:false,
    }
    this.handleBack=this.handleBack.bind(this)
    this.handleNext=this.handleNext.bind(this)
    this.setWidth=this.setWidth.bind(this)
  }

  stepResults(){
  }

  handleBack(event){
    const activeStep = this.state.activeStep
    if (activeStep>0)
     this.setState({activeStep:activeStep-1})
  }

  handleNext(event){
    const {activeStep, width, height, length, quantity, grade, color,
      handle_fee, reinforced_bottom} = this.state
      console.log("unit price:"+unitPriceTab[grade])
    console.log(this.state)
    if (activeStep === 0) {
      if (width*height*length*quantity === 0){
        alert("All these number must be entered.")
        return
      }
    }
    if (activeStep === 2){
      if ("A" !== this.state.grade)
        this.setState({reinforced_bottom:false})
    }
    var totalPrice=0
    if (activeStep === 3)
      totalPrice = width*height*length*quantity 
          *unitPriceTab[grade]
          *(1+colorPriceTab[color])
          +handle_fee*0.1*quantity
          +reinforced_bottom*0.05*quantity

    if (activeStep<4)
     this.setState({activeStep:activeStep+1,totalPrice:totalPrice})
  }

  setWidth(event){
    this.setState({width:event.target.value})
  }

  extrasCheckboxes(active) {
  if (active)
  return (
    <div style={{width:"50%",position:"relative",left:"300px", top:"20px"}}>
      <FormControl component="fieldset">
        <FormLabel component="legend">Optional extras</FormLabel>
        <FormGroup>
          <FormControlLabel
            control={<Checkbox checked={this.state.handle_fee}
            onChange={(e)=>{
              this.setState({handle_fee:!this.state.handle_fee})}}
            value="handle_fee" />}
            label="Handles: $0.10 per box"
          />
          <FormControlLabel
            control={<Checkbox checked={this.state.reinforced_bottom}
            onChange={(e)=>{
              var ri_btm = this.state.reinforced_bottom
              if ("A" === this.state.grade)
                ri_btm = !ri_btm
              else
                ri_btm = false
              this.setState({reinforced_bottom:ri_btm})}}
            value="reinforced_bottom" />}
            label="Reinforced bottom: $0.05 per box (only available with grade A cardboard)"
          />
        </FormGroup>
      </FormControl>
    </div>
  )}

  colorSelect(active){
  if (active)
  return (
    <div style={{width:"50%",position:"relative",left:"300px", top:"20px"}}>
    <form autoComplete="off">
      <FormControl>
        <InputLabel htmlFor="controlled-color-select">Select one of the options</InputLabel>
        <Select
          value={this.state.color}
          onChange={(e)=>{this.setState({color:e.target.value})}}
          inputProps={{
            name: 'color',
            id: 'controlled-color-select',
          }}
        >
          <MenuItem value="">
            <em>None</em>
          </MenuItem>
          <MenuItem value={0}>3 color printing: $0.20 M^2</MenuItem>
          <MenuItem value={1}>2 color printing: $0.10 M^2</MenuItem>
          <MenuItem value={2}>Black only printing: $0.05 M^2</MenuItem>
          <MenuItem value={3}>No printing (plain cardboard): free</MenuItem>
          <MenuItem value={4}>FantasticBoxCo branding: 5% discount on total price</MenuItem>
        </Select>
      </FormControl>
    </form>
    </div>
  )}

  gradeRadioGroup(active) {
    const {width, height, length } = this.state
  if (active)
  return (
    <div style={{width:"50%",position:"relative",left:"300px", top:"20px"}}>
      <FormControl component="fieldset">
        <FormLabel component="legend">Select a Grade: </FormLabel>
        <RadioGroup aria-label="grade" name="grade"
          value={this.state.grade}
          onChange={(e)=>{
            const select = e.target.value
            const size = width*height*length
            if ("C" === select)
              if (size>2) {
                alert("This option is not available for boxes larger than 2M^2")
                return
              }
            this.setState({grade:e.target.value})
        }}>
          <FormControlLabel value="A" control={<Radio />}
            label="A grade: $0.20 M^2" />
          <FormControlLabel value="B" control={<Radio />}
            label="B grade: $0.10 M^2" />
          <FormControlLabel value="C" control={<Radio />}
            label="C grade: $0.05 M^2" />
        </RadioGroup>
      </FormControl>
    </div>
  );
}
  inputNumbersGroup = (active)=> {
  //const classes = useStyles();
  if (active)
  return (
    <div style={{width:"50%",position:"relative",left:"300px",
        top:"20px"}}>
      <Grid container spacing={3}>
        <Grid item xs={8}>
      <FormControl component="fieldset" //className={classes.formControl}
      >
        <FormLabel component="legend">Enter Sizes of the Boxes</FormLabel>
        <FormLabel>Width: </FormLabel>
          <Input type="number" inputProps={{"step":"0.01"}}
            value={this.state.width}
            onChange = {(e)=>{this.setState({width:e.target.value})}} />
      </FormControl>
        </Grid>
        <Grid item xs={8}>
      <FormControl component="fieldset" //className={classes.formControl}
      >
        <FormGroup>
          <FormLabel component="legend">Height: </FormLabel>
          <Input type="number" inputProps={{"step":"0.01"}}
            value={this.state.height}
            onChange = {(e)=>{this.setState({height:e.target.value})}} />
        </FormGroup>
      </FormControl>
        </Grid>
        <Grid item xs={8}>
      <FormControl component="fieldset" //className={classes.formControl}
      >
        <FormGroup>
          <FormLabel component="legend">Length: </FormLabel>
          <Input type="number" inputProps={{"step":"0.01"}}
            value={this.state.length}
            onChange = {(e)=>{this.setState({length:e.target.value})}} />
        </FormGroup>
      </FormControl>
        </Grid>
        <Grid item xs={8}>
      <FormControl component="fieldset" //className={classes.formControl}
      >
        <FormGroup>
          <FormLabel component="legend">Quantity: </FormLabel>
          <Input type="number" inputProps={{"step":"1"}}
            value={this.state.quantity}
            onChange = {(e)=>{this.setState({quantity:e.target.value})}} />
        </FormGroup>
      </FormControl>
        </Grid>
      </Grid>
    </div>
  )}

  render(){
    const {
      activeStep,
      width,
      height,
      length,
      quantity,
      grade,
      color,
      handle_fee,
      reinforced_bottom} = this.state
      console.log("unit price:"+unitPriceTab[grade])
    const handles = handle_fee?"Yes":"No"
    const reinforces = reinforced_bottom?"Yes":"No"
    var results=[
     ["Width:"+width, "Height:"+height, "Length:"+length, "Quantity:"+quantity],
     ["Grade: "+grade],
     ["Colors: "+colorText[color]],
     ["Handles: "+handles,
      "Reinforced bottom: "+reinforces]]
    return (
      <div>
        <HorizontalStepper stepsTab = {steps}
          activeStep = {activeStep} content = {steps[activeStep].content} />
        <ShowCards steps={results} activeStep = {activeStep} />
        <Grid container spacing={3} style={{height:340}}>
        {this.inputNumbersGroup(this.state.activeStep === 0) }
        {this.gradeRadioGroup(this.state.activeStep === 1) }
        {this.colorSelect(this.state.activeStep === 2) }
        {this.extrasCheckboxes(this.state.activeStep === 3) }
        {(this.state.activeStep === 4) &&
      <div style={{width:"50%",position:"relative",left:"300px", top:"20px"}}>
          <p>The total price is:{parseFloat(this.state.totalPrice).toFixed(2)}</p>
      </div>}
        </Grid>
        <Divider />
        <Button color="primary" variant="contained" onClick={this.handleBack} 
              disabled={activeStep === 0}> Back
        </Button>
        <Button color="primary" variant="contained" onClick={this.handleNext} 
              disabled={activeStep === 4}> Next
        </Button>
      </div>
    )
  }
}
 
